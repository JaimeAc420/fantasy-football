/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Procesamiento;

import Clases.Equipo;
import Clases.Jugador;
import Clases.Partido;
import Clases.Usuario;
import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *
 * @author perzi
 */
public class Procesamiento {
    private final ArrayList<Usuario> usuariosSistema = new ArrayList<>();
    public ArrayList<Usuario> getUsuariosSistema(){
        return usuariosSistema;
    }
    public ArrayList<Usuario> cargarUsuarios() throws FileNotFoundException, IOException{
        String currentDirectory = new File("").getAbsolutePath();
        try (BufferedReader br = new BufferedReader(new FileReader(currentDirectory +"//src////Usuarios//usuarios.csv//"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            this.usuariosSistema.add(new Usuario(values[0], values[1], values[2],values[3]));
        }
        usuariosSistema.remove(0);
        return (ArrayList<Usuario>) usuariosSistema;
    }
    }
    private final ArrayList<Partido> partidosSistema = new ArrayList<>();
    public ArrayList<Partido> getPartidosSistema(){
        return partidosSistema;
    }
    public ArrayList<Partido> cargarPartidos() throws FileNotFoundException, IOException{
        String currentDirectory = new File("").getAbsolutePath();
        try (BufferedReader br = new BufferedReader(new FileReader(currentDirectory +"//src////Partidos//partidos.csv//"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            this.partidosSistema.add(new Partido(values[0], values[1], values[2],values[3]));
        }
        return (ArrayList<Partido>) partidosSistema;
    }
    }
    
    private final ArrayList<Jugador> jugadoresSistema = new ArrayList<>();
    public ArrayList<Jugador> getProyectosSistema(){
        return jugadoresSistema;
    }
    public ArrayList<Jugador> cargarDatosJugadores() throws FileNotFoundException, IOException, ParseException{
        String currentDirectory = new File("").getAbsolutePath();
        try (BufferedReader br = new BufferedReader(new FileReader(currentDirectory +"//src////Jugadores//jugadores.csv//"))){
            String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            String nombre=values[0];
            String posicion=values[1];
            int precio=Integer.parseInt(values[2]);
            String minutosJugados=values[3];
            int golesAnotados=Integer.parseInt(values[4]);
            int penaltisAnotados=Integer.parseInt(values[5]);
            int autoGoles=Integer.parseInt(values[6]);
            int asistencias=Integer.parseInt(values[7]);
            int golesRecibidos=Integer.parseInt(values[8]);
            int penaltisDetenidos=Integer.parseInt(values[9]);
            int penaltisErrados=Integer.parseInt(values[10]);
            int tarjetaAmarilla=Integer.parseInt(values[11]);
            int tarjetaRoja=Integer.parseInt(values[12]);
            int mano=Integer.parseInt(values[13]);
            int tiroLibre=Integer.parseInt(values[14]);
            int golTiroLibre=Integer.parseInt(values[15]);
            boolean golPartidosSeguidos=Boolean.parseBoolean(values[16]);
            boolean jugarPartidosSeguidos=Boolean.parseBoolean(values[17]);
            boolean campeonLiga=Boolean.parseBoolean(values[18]);
            boolean subCampeonLiga=Boolean.parseBoolean(values[19]);
            boolean terceroLiga=Boolean.parseBoolean(values[20]);
            boolean perdioPartido=Boolean.parseBoolean(values[21]);
            boolean ganoPartido=Boolean.parseBoolean(values[22]);
            boolean titularPartido=Boolean.parseBoolean(values[23]);
            this.jugadoresSistema.add(new Jugador(nombre, posicion, precio, minutosJugados, golesAnotados, penaltisAnotados, autoGoles, asistencias, golesRecibidos, penaltisDetenidos, penaltisErrados, tarjetaAmarilla, tarjetaRoja, mano, tiroLibre, golTiroLibre, golPartidosSeguidos, jugarPartidosSeguidos, campeonLiga, subCampeonLiga, terceroLiga, perdioPartido, ganoPartido, titularPartido));
        }
        }
        return (ArrayList<Jugador>) jugadoresSistema; 
    }
    private final ArrayList<Equipo> equiposSistema = new ArrayList<>();
    public ArrayList<Equipo> getEquiposSistema(){
        return equiposSistema;
    }
    public ArrayList<Equipo> cargarEquipos() throws FileNotFoundException, IOException{
        String currentDirectory = new File("").getAbsolutePath();
        try (BufferedReader br = new BufferedReader(new FileReader(currentDirectory +"//src////Equipos//equipos.csv//"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            this.equiposSistema.add(new Equipo(values[0], Integer.parseInt(values[1]), Integer.parseInt(values[2]),values[3]));
        }
        return (ArrayList<Equipo>) equiposSistema;
    }
    }
    
    
}

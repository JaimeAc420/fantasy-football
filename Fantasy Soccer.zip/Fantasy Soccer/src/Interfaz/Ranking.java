/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import Clases.Equipo;
import Clases.Jugador;
import Clases.Usuario;
import Procesamiento.Procesamiento;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;

/**
 *
 * @author perzi
 */
public class Ranking extends javax.swing.JFrame {
    Usuario usuario= new Usuario();
    Procesamiento p1= new Procesamiento();
    ArrayList<Equipo> equiposSistema= new ArrayList<>();
    ArrayList<Jugador> jugadoresSistema= new ArrayList<>();
    ArrayList<String> jugadoresEquipo = new ArrayList<>();
    ArrayList<Jugador> jugadoresPosicion = new ArrayList<>();
    DefaultListModel<String> modelo=new DefaultListModel<>();
    
    public ArrayList<Equipo> puntajes(ArrayList<Equipo> equiposSistema, ArrayList<Jugador> jugadoresSistema, ArrayList<String> jugadoresEquipo) throws IOException{
        ArrayList<Jugador> newList= new ArrayList<>();
        for (int i=0;i<equiposSistema.size();i++){
            cargarJugadoresEquipo(equiposSistema.get(i));
            newList= jugadoresInfo(jugadoresEquipo, jugadoresSistema);
            int puntosEquipo=puntos(newList);
            equiposSistema.get(i).setPuntos(puntosEquipo);
        }
        return equiposSistema;
    }
    
    public ArrayList<String> cargarJugadoresEquipo(Equipo equipo1) throws FileNotFoundException, IOException{
        String currentDirectory = new File("").getAbsolutePath();
        try (BufferedReader br = new BufferedReader(new FileReader(currentDirectory +"//src////"+equipo1.getNombre()+"//JugadoresEquipo.csv//"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split("/n");
            this.jugadoresEquipo.add(values[0]);
        }
    }
        return jugadoresEquipo;
    }
    
    public ArrayList<Jugador> jugadoresInfo(ArrayList<String> jugadoresEquipo, ArrayList<Jugador> jugadoresSistema) {                                             
        for (int i=0;i<jugadoresEquipo.size();i++){
            for (int x=0;x<jugadoresSistema.size();x++){
                String[] values =jugadoresEquipo.get(i).split(",");
                String nombre=values[0];
                String posicion=values[1];
                if (nombre.equals(jugadoresSistema.get(i).getNombre())){
                        jugadoresPosicion.add(jugadoresSistema.get(i));
                }                
        }           
        }
        // Create a new ArrayList
        ArrayList<Jugador> newList = new ArrayList<>();
  
        // Traverse through the first list
        for (Jugador element : jugadoresPosicion) {
  
            // If this element is not present in newList
            // then add it
            if (!newList.contains(element)) {
  
                newList.add(element);
            }
        }
        return newList;
    }
    public int puntos(ArrayList<Jugador> newList){
        int puntosTotal=0;
        for (int i=0;i<newList.size();i++){
            int minutosJugados=Integer.parseInt(newList.get(i).getMinutosJugados());
            if (minutosJugados==60){
                puntosTotal+=1;
            }if (minutosJugados>60){
                puntosTotal+=2;
            }
            if (newList.get(i).getPosicion().equals("Delantero")){
                int goles=newList.get(i).getGolesAnotados()*4;
                puntosTotal+=goles;
            }if (newList.get(i).getPosicion().equals("Mediocampista")){
                int goles=newList.get(i).getGolesAnotados()*5;
                puntosTotal+=goles;
            }if (newList.get(i).getPosicion().equals("Arquero") || newList.get(i).getPosicion().equals("Defensa")){
                int goles=newList.get(i).getGolesAnotados()*6;
                puntosTotal+=goles;
            }
            puntosTotal=puntosTotal+(newList.get(i).getAsistencias()*3);
            if (newList.get(i).getPosicion().equals("Arquero") && newList.get(i).getGolesRecibidos()==0|| newList.get(i).getPosicion().equals("Defensa") && newList.get(i).getGolesRecibidos()==0){
                puntosTotal+=4;
            }
            if(newList.get(i).getPosicion().equals("Arquero") && newList.get(i).getPenaltisDetenidos()>1){
                puntosTotal+=5;
            }
            puntosTotal=puntosTotal+(newList.get(i).getPenaltisErrados()*-2);
            puntosTotal=puntosTotal+(newList.get(i).getTarjetaAmarilla()*-1);
            puntosTotal=puntosTotal+(newList.get(i).getTarjetaRoja()*-3);
            puntosTotal=puntosTotal+(newList.get(i).getAutoGoles()*-2);
            puntosTotal=puntosTotal+(newList.get(i).getMano()*-1);
            puntosTotal=puntosTotal+newList.get(i).getTiroLibre();
            if (newList.get(i).getPosicion().equals("Delantero")){
                int goles=newList.get(i).getGolTiroLibre()*6;
                puntosTotal+=goles;
            }
            if (newList.get(i).getPosicion().equals("Mediocampista")){
                int goles=newList.get(i).getGolTiroLibre()*7;
                puntosTotal+=goles;
            }
            if (newList.get(i).getPosicion().equals("Arquero") || newList.get(i).getPosicion().equals("Defensa")){
                int goles=newList.get(i).getGolTiroLibre()*8;
                puntosTotal+=goles;
            }if (newList.get(i).isGolPartidosSeguidos()==true){
                puntosTotal+=10;
                
            }if (newList.get(i).isJugarPartidosSeguidos()==true){
                puntosTotal+=5;
            }if (newList.get(i).isCampeonLiga()==true){
                puntosTotal+=10;
            }if (newList.get(i).isSubCampeonLiga()==true){
                puntosTotal+=7;
            }if (newList.get(i).isTerceroLiga()==true){
                puntosTotal+=5;
            }
        }
        return puntosTotal;
    }

    /**
     * Creates new form Ranking
     */
    public Ranking() {
        initComponents();
    }
    
    public Ranking(Usuario usuario1) throws IOException, FileNotFoundException, ParseException {
        initComponents();
        usuario=usuario1;
        equiposSistema= p1.cargarEquipos();
        jugadoresSistema=p1.cargarDatosJugadores();
        puntajes(equiposSistema,jugadoresSistema,jugadoresEquipo);
        Collections.sort(equiposSistema, Comparator.comparing((integer) -> integer.getPuntos()));
        listEquipos.setModel(modelo);
        for (int i=0;i<equiposSistema.size();i++){
            modelo.addElement(equiposSistema.get(i).getNombre()+" / "+String.valueOf(equiposSistema.get(i).getPuntos()).trim());        
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtTitulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listEquipos = new javax.swing.JList<>();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 0));
        jPanel1.setLayout(null);

        txtTitulo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txtTitulo.setForeground(new java.awt.Color(255, 255, 255));
        txtTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTitulo.setText("Ranking");
        jPanel1.add(txtTitulo);
        txtTitulo.setBounds(120, 10, 160, 30);

        jScrollPane1.setViewportView(listEquipos);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 70, 360, 200);

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(140, 330, 100, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        try {
            String currentDirectory = new File("").getAbsolutePath();
            FileWriter csvWriter;
            csvWriter = new FileWriter(currentDirectory +"//src////Equipos//equipos.csv//");
            for (Equipo rowData : equiposSistema) {
                csvWriter.append(String.join(",", rowData.getNombre()+","));
                csvWriter.append(String.join(",", rowData.getPresupuesto()+","));
                csvWriter.append(String.join(",", rowData.getPuntos()+","));
                csvWriter.append(String.join(",", rowData.getDueno()));
                csvWriter.append("\n");
            }
            csvWriter.flush();
            csvWriter.close();
            new Menu_Usuario(usuario).setVisible(true);
            this.setVisible(false);
        } catch (IOException ex) {
            Logger.getLogger(Ranking.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ranking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVolver;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listEquipos;
    private javax.swing.JLabel txtTitulo;
    // End of variables declaration//GEN-END:variables
}

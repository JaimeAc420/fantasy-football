/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author perzi
 */
public class Jugador {
    
    private String nombre;
    private String posicion;
    private int precio;
    private String minutosJugados;
    private int golesAnotados;
    private int penaltisAnotados;
    private int autoGoles;
    private int asistencias;
    private int golesRecibidos;
    private int penaltisDetenidos;
    private int penaltisErrados;
    private int tarjetaAmarilla;
    private int tarjetaRoja;
    private int mano;
    private int tiroLibre;
    private int golTiroLibre;
    private boolean golPartidosSeguidos;
    private boolean jugarPartidosSeguidos;
    private boolean campeonLiga;
    private boolean subCampeonLiga;
    private boolean terceroLiga;
    private boolean perdioPartido;
    private boolean ganoPartido;
    private boolean titularPartido;

    public Jugador() {
    }

    public Jugador(String nombre, String posicion, int precio, String minutosJugados, int golesAnotados, int penaltisAnotados, int autoGoles, int asistencias, int golesRecibidos, int penaltisDetenidos, int penaltisErrados, int tarjetaAmarilla, int tarjetaRoja, int mano, int tiroLibre, int golTiroLibre, boolean golPartidosSeguidos, boolean jugarPartidosSeguidos, boolean campeonLiga, boolean subCampeonLiga, boolean terceroLiga, boolean perdioPartido, boolean ganoPartido, boolean titularPartido) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.precio = precio;
        this.minutosJugados = minutosJugados;
        this.golesAnotados = golesAnotados;
        this.penaltisAnotados = penaltisAnotados;
        this.autoGoles = autoGoles;
        this.asistencias = asistencias;
        this.golesRecibidos = golesRecibidos;
        this.penaltisDetenidos = penaltisDetenidos;
        this.penaltisErrados = penaltisErrados;
        this.tarjetaAmarilla = tarjetaAmarilla;
        this.tarjetaRoja = tarjetaRoja;
        this.mano = mano;
        this.tiroLibre = tiroLibre;
        this.golTiroLibre = golTiroLibre;
        this.golPartidosSeguidos = golPartidosSeguidos;
        this.jugarPartidosSeguidos = jugarPartidosSeguidos;
        this.campeonLiga = campeonLiga;
        this.subCampeonLiga = subCampeonLiga;
        this.terceroLiga = terceroLiga;
        this.perdioPartido = perdioPartido;
        this.ganoPartido = ganoPartido;
        this.titularPartido = titularPartido;
    }
    

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the posicion
     */
    public String getPosicion() {
        return posicion;
    }

    /**
     * @param posicion the posicion to set
     */
    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    /**
     * @return the precio
     */
    public int getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(int precio) {
        this.precio = precio;
    }

    /**
     * @return the minutosJugados
     */
    public String getMinutosJugados() {
        return minutosJugados;
    }

    /**
     * @param minutosJugados the minutosJugados to set
     */
    public void setMinutosJugados(String minutosJugados) {
        this.minutosJugados = minutosJugados;
    }

    /**
     * @return the golesAnotados
     */
    public int getGolesAnotados() {
        return golesAnotados;
    }

    /**
     * @param golesAnotados the golesAnotados to set
     */
    public void setGolesAnotados(int golesAnotados) {
        this.golesAnotados = golesAnotados;
    }

    /**
     * @return the penaltisAnotados
     */
    public int getPenaltisAnotados() {
        return penaltisAnotados;
    }

    /**
     * @param penaltisAnotados the penaltisAnotados to set
     */
    public void setPenaltisAnotados(int penaltisAnotados) {
        this.penaltisAnotados = penaltisAnotados;
    }

    /**
     * @return the autoGoles
     */
    public int getAutoGoles() {
        return autoGoles;
    }

    /**
     * @param autoGoles the autoGoles to set
     */
    public void setAutoGoles(int autoGoles) {
        this.autoGoles = autoGoles;
    }

    /**
     * @return the asistencias
     */
    public int getAsistencias() {
        return asistencias;
    }

    /**
     * @param asistencias the asistencias to set
     */
    public void setAsistencias(int asistencias) {
        this.asistencias = asistencias;
    }

    /**
     * @return the golesRecibidos
     */
    public int getGolesRecibidos() {
        return golesRecibidos;
    }

    /**
     * @param golesRecibidos the golesRecibidos to set
     */
    public void setGolesRecibidos(int golesRecibidos) {
        this.golesRecibidos = golesRecibidos;
    }

    /**
     * @return the penaltisDetenidos
     */
    public int getPenaltisDetenidos() {
        return penaltisDetenidos;
    }

    /**
     * @param penaltisDetenidos the penaltisDetenidos to set
     */
    public void setPenaltisDetenidos(int penaltisDetenidos) {
        this.penaltisDetenidos = penaltisDetenidos;
    }

    /**
     * @return the penaltisErrados
     */
    public int getPenaltisErrados() {
        return penaltisErrados;
    }

    /**
     * @param penaltisErrados the penaltisErrados to set
     */
    public void setPenaltisErrados(int penaltisErrados) {
        this.penaltisErrados = penaltisErrados;
    }

    /**
     * @return the tarjetaAmarilla
     */
    public int getTarjetaAmarilla() {
        return tarjetaAmarilla;
    }

    /**
     * @param tarjetaAmarilla the tarjetaAmarilla to set
     */
    public void setTarjetaAmarilla(int tarjetaAmarilla) {
        this.tarjetaAmarilla = tarjetaAmarilla;
    }

    /**
     * @return the tarjetaRoja
     */
    public int getTarjetaRoja() {
        return tarjetaRoja;
    }

    /**
     * @param tarjetaRoja the tarjetaRoja to set
     */
    public void setTarjetaRoja(int tarjetaRoja) {
        this.tarjetaRoja = tarjetaRoja;
    }

    /**
     * @return the mano
     */
    public int getMano() {
        return mano;
    }

    /**
     * @param mano the mano to set
     */
    public void setMano(int mano) {
        this.mano = mano;
    }

    /**
     * @return the tiroLibre
     */
    public int getTiroLibre() {
        return tiroLibre;
    }

    /**
     * @param tiroLibre the tiroLibre to set
     */
    public void setTiroLibre(int tiroLibre) {
        this.tiroLibre = tiroLibre;
    }

    /**
     * @return the golTiroLibre
     */
    public int getGolTiroLibre() {
        return golTiroLibre;
    }

    /**
     * @param golTiroLibre the golTiroLibre to set
     */
    public void setGolTiroLibre(int golTiroLibre) {
        this.golTiroLibre = golTiroLibre;
    }

    /**
     * @return the golPartidosSeguidos
     */
    public boolean isGolPartidosSeguidos() {
        return golPartidosSeguidos;
    }

    /**
     * @param golPartidosSeguidos the golPartidosSeguidos to set
     */
    public void setGolPartidosSeguidos(boolean golPartidosSeguidos) {
        this.golPartidosSeguidos = golPartidosSeguidos;
    }

    /**
     * @return the jugarPartidosSeguidos
     */
    public boolean isJugarPartidosSeguidos() {
        return jugarPartidosSeguidos;
    }

    /**
     * @param jugarPartidosSeguidos the jugarPartidosSeguidos to set
     */
    public void setJugarPartidosSeguidos(boolean jugarPartidosSeguidos) {
        this.jugarPartidosSeguidos = jugarPartidosSeguidos;
    }

    /**
     * @return the campeonLiga
     */
    public boolean isCampeonLiga() {
        return campeonLiga;
    }

    /**
     * @param campeonLiga the campeonLiga to set
     */
    public void setCampeonLiga(boolean campeonLiga) {
        this.campeonLiga = campeonLiga;
    }

    /**
     * @return the subCampeonLiga
     */
    public boolean isSubCampeonLiga() {
        return subCampeonLiga;
    }

    /**
     * @param subCampeonLiga the subCampeonLiga to set
     */
    public void setSubCampeonLiga(boolean subCampeonLiga) {
        this.subCampeonLiga = subCampeonLiga;
    }

    /**
     * @return the terceroLiga
     */
    public boolean isTerceroLiga() {
        return terceroLiga;
    }

    /**
     * @param terceroLiga the terceroLiga to set
     */
    public void setTerceroLiga(boolean terceroLiga) {
        this.terceroLiga = terceroLiga;
    }

    /**
     * @return the perdioPartido
     */
    public boolean isPerdioPartido() {
        return perdioPartido;
    }

    /**
     * @param perdioPartido the perdioPartido to set
     */
    public void setPerdioPartido(boolean perdioPartido) {
        this.perdioPartido = perdioPartido;
    }

    /**
     * @return the ganoPartido
     */
    public boolean isGanoPartido() {
        return ganoPartido;
    }

    /**
     * @param ganoPartido the ganoPartido to set
     */
    public void setGanoPartido(boolean ganoPartido) {
        this.ganoPartido = ganoPartido;
    }

    /**
     * @return the titularPartido
     */
    public boolean isTitularPartido() {
        return titularPartido;
    }

    /**
     * @param titularPartido the titularPartido to set
     */
    public void setTitularPartido(boolean titularPartido) {
        this.titularPartido = titularPartido;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


//Importa de "librerias"
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;

/**
 *
 * @author perzi
 */
public class BarChart_AWT extends ApplicationFrame {
    public BarChart_AWT( String applicationTitle , String chartTitle, int sum, int sum1, int sum2, int sum3, int sum4, int sum5, int sum6, int sum7, int sum8, int sum9, int sum10, int sum11, String posicion) {
      super( applicationTitle );        
      JFreeChart barChart = ChartFactory.createBarChart(
         chartTitle,           
         "Category",            
         "Score",       
         createDataset(sum, sum1, sum2, sum3, sum4, sum5, sum6, sum7, sum8, sum9, sum10, sum11, posicion),
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );        
      setContentPane( chartPanel ); 
   }
    private CategoryDataset createDataset(int sum, int sum1, int sum2, int sum3, int sum4, int sum5, int sum6, int sum7, int sum8, int sum9, int sum10, int sum11, String posicion) {        
      final DefaultCategoryDataset dataset = 
      new DefaultCategoryDataset( );  

      dataset.addValue(sum, posicion ,"golesAnotados"); 
      dataset.addValue(sum1, posicion ,"penaltisAnotados"); 
      dataset.addValue(sum2, posicion ,"autoGoles"); 
      dataset.addValue(sum3, posicion ,"asistencias"); 
      dataset.addValue(sum4, posicion ,"golesRecibidos");
      dataset.addValue(sum5, posicion ,"penaltisDetenidos");
      dataset.addValue(sum6, posicion ,"penaltisErrados");
      dataset.addValue(sum7, posicion ,"tarjetaAmarilla");
      dataset.addValue(sum8, posicion ,"tarjetaRoja");
      dataset.addValue(sum9, posicion ,"mano");
      dataset.addValue(sum10, posicion ,"tiroLibre");
      dataset.addValue(sum11, posicion ,"golTiroLibre");
      return dataset; 
   }
    
}
